﻿namespace DLLClass
{
    public class Class1
    {

    }
}
