﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace ProyectoNuevo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void toolStripContainer1_ContentPanel_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            contrasenna.UseSystemPasswordChar = !contrasenna.UseSystemPasswordChar;

            botonContrasenna.Text = contrasenna.UseSystemPasswordChar ? "mostrar" : "ocultar";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            usuario.ResetText();
            contrasenna.ResetText();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String mensaje = usuario.Text;
            String mensajeC = contrasenna.Text;
            String usuarioPredeterminado = "Camila";
            Image img = imagen.Image;
         

            caja.Text = mensajeC;
            caja.Text = mensaje;
            caja.Text = usuarioPredeterminado;
            imagen.Image = img; 
            

            usuario.ResetText();
            contrasenna.ResetText();
            imagen.Show();  
            
         
      

            if (String.IsNullOrEmpty(mensaje))
            {
                MessageBox.Show("El campo 'Usuario' está vacío", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }else if (String.IsNullOrEmpty(mensajeC)) {
                MessageBox.Show("El campo 'contraseña' está vacío","Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }else if (usuarioPredeterminado.Equals(mensaje)){
            
                Visible = true;
                
                return ;
            }else if (usuario.Text != null)
            {
                Show(Form2);
            }
            {
            
          
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
    
}