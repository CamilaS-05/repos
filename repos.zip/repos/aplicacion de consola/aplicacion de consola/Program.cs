﻿// See https://aka.ms/new-console-template for more information
namespace aplicacionDeConsola{
    using DLL;
    class Program
    {
        static void Main(string[] args)
        {

            int result = DLLClass.Divide(20, 5);
            Console.WriteLine(result);

            Console.Read();
        }
    }
}