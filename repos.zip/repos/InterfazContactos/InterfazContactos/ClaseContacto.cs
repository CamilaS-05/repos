﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


   class ClaseContacto
    {

        private string name;
        private string phone;

        public ClaseContacto()
        {
            name = "";
            phone = "";
        }

        public ClaseContacto(string nombre, string telefono)
        {
            name = nombre;
            phone = telefono;
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }
            ClaseContacto c = (ClaseContacto)obj;
            return Name == c.Name && Phone == c.Phone;
        }
        public override int GetHashCode()
        {
            return HashCode.Combine(Name, Phone);
        }
    }

