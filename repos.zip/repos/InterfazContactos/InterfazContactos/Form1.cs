﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;


namespace InterfazContactos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private List<ClaseContacto> contacto = new List<ClaseContacto>();
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        // Evento para buscar contacto por número de teléfono
        private void button1_Click(object sender, EventArgs e)
        {
            // Llamar al método searchContact de ClasePrograma
            ClasePrograma.searchContact(contacto);
        }

        // Evento para insertar un nuevo contacto
        private void button2_Click(object sender, EventArgs e)
        {
            // Llamar al método insertContact de ClasePrograma
            ClasePrograma.insertContact(contacto);
        }

        // Evento para actualizar un contacto existente
        private void button3_Click(object sender, EventArgs e)
        {
            // Llamar al método updateContact de ClasePrograma
            ClasePrograma.updateContact(contacto);
        }

        // Evento para eliminar un contacto
        private void button4_Click(object sender, EventArgs e)
        {
            // Llamar al método deleteContact de ClasePrograma
            ClasePrograma.deleteContact(contacto);
        }

        // Evento para salir
        private void button5_Click(object sender, EventArgs e)
        {
            // Salir de la aplicación
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

